//---------------------------------------------------------------------------


#pragma hdrstop

#include "util.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)

void Right()
{
  // right part of string
}